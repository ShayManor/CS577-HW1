"""Homework checker and submission commands."""
import argparse
from . import runner, submit


def main(argv=None):
    parser = argparse.ArgumentParser(prog="hw1")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("check", add_help=False, help="Check code and report its coding score")
    commands.add_parser("submit", add_help=False, help="Submit a Python file with turnin")
    args, remaining = parser.parse_known_args(argv)
    return {"check": runner.main, "submit": submit.main}[args.command](remaining)
