"""CS 577 Homework 1 offline checker."""
__version__ = "1.3.0"
