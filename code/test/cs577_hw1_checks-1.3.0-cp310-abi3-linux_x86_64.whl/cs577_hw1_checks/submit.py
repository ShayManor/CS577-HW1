"""Collect the homework deliverables and submit them through the server's turnin."""
import argparse
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile


def collect(source):
    source = Path(source)
    if source.is_symlink() or not source.is_file() or source.stat().st_size == 0:
        raise ValueError("Missing, empty, or symbolic-link submission")
    return [(source, "hw1.py")]


def main(argv=None):
    parser = argparse.ArgumentParser(prog="hw1 submit", description="Submit CS 577 HW1 using turnin on the course Linux server.")
    source = parser.add_mutually_exclusive_group()
    source.add_argument("--submission", type=Path, help="Python file to submit (default: hw1.py)")
    source.add_argument("--directory", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--dry-run", action="store_true", help="Validate and list the files without invoking turnin.")
    args = parser.parse_args(argv)
    if sys.platform != "linux":
        print("Run this command on the course Linux server.", file=sys.stderr)
        return 2
    try:
        path = args.submission if args.submission is not None else (args.directory or Path(".")) / "hw1.py"
        files = collect(path.absolute())
    except (OSError, ValueError) as exc:
        print(f"Cannot prepare submission: {exc}", file=sys.stderr)
        return 2
    print("Course: cs577; project: hw1")
    print("Submitting replaces your previous submission for this project.")
    for _, name in files:
        print("  " + name)
    names = ["./" + name for _, name in files]
    command = ["turnin", "-c", "cs577", "-p", "hw1", *names]
    print("Command (from a temporary directory containing these files):")
    print(shlex.join(command), flush=True)
    if args.dry_run:
        print("Dry run: no files submitted.")
        return 0
    executable = shutil.which("turnin")
    if executable is None:
        print("turnin is not on PATH. Use the course server and its configured environment.", file=sys.stderr)
        return 2
    try:
        with tempfile.TemporaryDirectory(prefix="cs577-hw1-submit-") as tmp:
            stage = Path(tmp)
            for source, name in files:
                target = stage / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
            # No shell: file names cannot become shell commands. Preserve the
            # terminal so turnin can prompt for a section if the server needs it.
            result = subprocess.run([executable, *command[1:]], cwd=stage, check=False)
    except OSError as exc:
        print(f"Submission could not run: {exc}", file=sys.stderr)
        return 2
    if result.returncode != 0:
        print(f"turnin failed (exit {result.returncode}); submission was not confirmed.", file=sys.stderr)
        return 1
    print("turnin completed successfully. Verify the recorded files with:")
    print("turnin -c cs577 -p hw1 -v")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
