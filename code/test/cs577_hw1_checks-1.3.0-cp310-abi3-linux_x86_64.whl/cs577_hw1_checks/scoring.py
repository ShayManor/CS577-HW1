"""Points for each check; optional and diagnostic checks carry no points."""

# ID: (task, weight, kind)
CHECKS = {
    'DataTests.test_jsonl_unicode_and_blanks': (1, 1, 'required'),
    'DataTests.test_bad_records': (1, 1, 'required'),
    'DataTests.test_duplicate_ids': (1, 1, 'required'),
    'DataTests.test_vocab_deterministic_and_frequency': (1, 1, 'required'),
    'DataTests.test_encoding_does_not_grow_vocab': (1, 1, 'required'),
    'DataTests.test_id_windows': (1, 1, 'required'),
    'DataTests.test_one_word_and_radius_zero': (1, 1, 'required'),
    'DataTests.test_vector_windows_and_gradients': (1, 1, 'required'),
    'FeatureTests.test_suffix_vocabulary': (2, 2, 'required'),
    'FeatureTests.test_exact_features_and_no_refit': (2, 4, 'required'),
    'FeatureTests.test_sentence_position_resets': (2, 1, 'required'),
    'ModelTests.test_mlp_structure': (3, 3, 'required'),
    'ModelTests.test_mlp_raw_logits_numerically': (3, 2, 'required'),
    'ModelTests.test_word_tagger_padding_and_trainability': (3, 3, 'required'),
    'ModelTests.test_window_order_and_feature_concatenation': (3, 2, 'required'),
    'SubwordTests.test_qwen_boundary_convention': (4, 2.5, 'required'),
    'SubwordTests.test_masked_mean_and_all_padding': (4, 2.5, 'required'),
    'ModelTests.test_qwen_without_projection': (4, 3, 'required'),
    'SubwordTests.test_first_subword_positions': (5, 1, 'required'),
    'SubwordTests.test_bad_word_alignment': (5, 1, 'required'),
    'SubwordTests.test_bert_extraction_frozen_and_aligned': (5, 3, 'required'),
    'SubwordTests.test_bert_no_silent_truncation': (5, 1, 'required'),
    'TrainingTests.test_evaluation_weighting_order_mask_and_no_update': (6, 2, 'required'),
    'TrainingTests.test_training_weighted_metrics_without_updates': (6, 1, 'required'),
    'TrainingTests.test_one_sgd_update_and_zero_grad': (6, 1.5, 'required'),
    'TrainingTests.test_all_ignored_batch_is_skipped': (6, 1, 'required'),
    'TrainingTests.test_no_valid_labels_rejected': (6, 0.5, 'required'),
    'ModelTests.test_qwen_shared_projection_and_no_activation': (4, 0, 'optional'),
    'ModelTests.test_qwen_projection_gets_gradients': (4, 0, 'optional'),
    'ModelTests.test_bert_tagger_output_shape': (5, 0, 'diagnostic'),
    'SubwordTests.test_empty_tokenization_rejected': (4, 0, 'diagnostic'),
    'TrainingTests.test_tiny_realizable_data_can_be_learned': (6, 0, 'diagnostic'),
    'SupportTests.test_slices_use_training_data_not_model_vocabulary': (None, 0, 'diagnostic'),
    'SupportTests.test_empty_slice_is_none': (None, 0, 'diagnostic'),
    'SupportTests.test_prediction_count_rejected': (None, 0, 'diagnostic'),
    'SupportTests.test_cache_fingerprint_detects_changed_words': (None, 0, 'diagnostic'),
    'SupportTests.test_error_selection_is_fixed': (None, 0, 'diagnostic'),
    'SupportTests.test_disjoint_splits': (None, 0, 'diagnostic'),
}

TASK_TOTALS = {1: 8, 2: 7, 3: 10, 4: 8, 5: 6, 6: 6}
TOTAL_POINTS = sum(TASK_TOTALS.values())

def consolidate(checks):
    ids = [c["id"] for c in checks]
    if len(ids) != len(CHECKS) or set(ids) != set(CHECKS):
        raise ValueError("Checker case inventory does not match the scoring map")
    tasks = []
    for task, weight in TASK_TOTALS.items():
        earned = sum(c["earned"] for c in checks if c["task"] == task)
        tasks.append({"task": task, "earned": earned, "weight": weight})
    return sum(t["earned"] for t in tasks), tasks
