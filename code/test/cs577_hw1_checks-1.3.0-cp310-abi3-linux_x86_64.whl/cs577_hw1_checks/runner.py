"""Public reporting interface; test implementations live in compiled extensions."""
import argparse
import contextlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import unittest

from . import __version__
from .scoring import CHECKS, TOTAL_POINTS, consolidate

RANK = {"pass": 0, "skip": 1, "unimplemented": 2, "fail": 3, "error": 4}
HINTS = {
    "pass": "Passed.",
    "skip": "Check skipped; this does not count as a pass.",
    "unimplemented": "A required function still raises NotImplementedError.",
    "fail": "Output or behavior does not satisfy this check. Review the named requirement.",
    "error": "An exception prevented this check from completing. Debug the named functionality locally.",
}


class ReportResult(unittest.TestResult):
    def __init__(self):
        super().__init__()
        self.checks = []

    def startTest(self, test):
        super().startTest(test)
        case_id = test.id().split(".")[-2] + "." + test._testMethodName
        task, weight, kind = CHECKS[case_id]
        self.current = {
            "id": case_id,
            "task": task, "weight": weight, "earned": 0, "kind": kind,
            "group": f"Task {task}" if task is not None else "Supplied utilities",
            "name": test._testMethodName.removeprefix("test_").replace("_", " "),
            "status": "pass",
        }

    def mark(self, status):
        if RANK[status] > RANK[self.current["status"]]:
            self.current["status"] = status

    def addSuccess(self, test):
        pass

    def addError(self, test, err):
        self.mark("unimplemented" if issubclass(err[0], NotImplementedError) else "error")
        self.errors.append((test, "Exception details withheld."))

    def addFailure(self, test, err):
        self.mark("fail")
        self.failures.append((test, "Assertion details withheld."))

    def addSkip(self, test, reason):
        self.mark("skip")
        self.skipped.append((test, "Skip details withheld."))

    def addSubTest(self, test, subtest, err):
        if err is not None:
            if issubclass(err[0], test.failureException):
                self.addFailure(test, err)
            else:
                self.addError(test, err)

    def stopTest(self, test):
        self.current["earned"] = self.current["weight"] if self.current["status"] == "pass" else 0
        self.current["message"] = HINTS[self.current["status"]]
        self.checks.append(self.current)
        super().stopTest(test)


def load_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError("Cannot load module")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def main(argv=None):
    parser = argparse.ArgumentParser(prog="hw1 check", description="Run the offline CS 577 HW1 checks.")
    parser.add_argument("--submission", type=Path, default=Path("hw1.py"))
    parser.add_argument("--support", type=Path, help="Override the bundled supplied support.py.")
    parser.add_argument("--report", type=Path, default=Path("check_report.json"))
    args = parser.parse_args(argv)
    if sys.platform != "linux":
        print("Run the checker on the course Linux server.", file=sys.stderr)
        return 2
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    submission = args.submission.resolve()
    support = args.support.resolve() if args.support else Path(__file__).with_name("_support.py")
    report = {"checker_version": __version__, "checks": [], "passed": 0, "total": 0,
              "score": None, "max_score": TOTAL_POINTS, "tasks": []}
    exit_code = 2
    # Suppress source-bearing student output and exception strings. Reports contain
    # only fixed descriptions. This is a local feedback tool, not a grading sandbox.
    try:
        if not submission.is_file() or not support.is_file():
            raise FileNotFoundError("Submission or support file missing")
        sys.path.insert(0, str(submission.parent))
        with open(os.devnull, "w") as quiet, contextlib.redirect_stdout(quiet), contextlib.redirect_stderr(quiet):
            load_file("hw1", submission)
            load_file("support", support)
            os.environ["HW1_MODULE"] = "hw1"
            suite = unittest.TestSuite()
            for name in ("_contracts", "_utilities"):
                module = importlib.import_module("cs577_hw1_checks." + name)
                suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
            result = ReportResult()
            suite.run(result)
        report["checks"] = result.checks
        report["total"] = len(result.checks)
        report["passed"] = sum(c["status"] == "pass" for c in result.checks)
        report["score"], report["tasks"] = consolidate(result.checks)
        report["status"] = "pass" if report["score"] == TOTAL_POINTS else "fail"
        exit_code = 0 if report["status"] == "pass" else 1
    except Exception:
        report["status"] = "setup_error"
        report["message"] = (
            "Could not load the submission, supplied support.py, or checker dependencies. "
            "Check the file paths and run your module directly to debug import errors."
        )
    for check in report["checks"]:
        print(f"[{check['status'].upper():13}] {check['earned']:g}/{check['weight']:g} points "
              f"{check['group']} — {check['name']} ({check['kind']})")
        if check["status"] != "pass":
            print("                " + check["message"])
    print(f"\n{report['passed']}/{report['total']} checks passed.")
    for task in report["tasks"]:
        print(f"Task {task['task']}: {task['earned']:g}/{task['weight']:g}")
    if report["score"] is None:
        print("Coding score: unavailable (checker setup failed).")
    else:
        print(f"Coding score: {report['score']:g}/{report['max_score']:g}")
    if "message" in report:
        print(report["message"])
    try:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        print(f"Report: {args.report}")
    except OSError:
        print("Could not write the report; choose a writable --report path.", file=sys.stderr)
        return 2
    return exit_code
